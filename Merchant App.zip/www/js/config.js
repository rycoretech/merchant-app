
var krms_config ={					
	'ApiUrl':"http://dining500.com/merchantapp/api",
	'DialogDefaultTitle':"Dining 500",
	'APIHasKey':"5f6f86e5e44d721300316b7905f404197ef397e622",
	'debug': false
};